package com.ejemplo.E02NorthWindRest.Entities;

import java.sql.Blob;

import javax.json.bind.annotation.JsonbPropertyOrder;

@JsonbPropertyOrder({"id", 
    		     	 "supplier_ids", 
    		     	 "product_code", 
    		     	 "product_name", 
                     "description", 
                     "standard_cost", 
                     "list_price", 
                     "reorder_level", 
                     "target_level", 
                     "quantity_per_unit", 
                     "discontinued", 
                     "minimum_reorder_quantity", 
                     "category",
                     "attachments"})
public class Product {
	private Integer id;
	private String supplier_ids;
	private String product_code;
	private String product_name;
	private String description;
	private String standard_cost;
	private String list_price;
	private String reorder_level;
	private String target_level;
	private String quantity_per_unit;
	private String discontinued;
	private String minimum_reorder_quantity;
	private String category;
	private Blob attachments;
	
	public Product() {

	}

	public Product(Integer id, String supplier_ids, String product_code, String product_name, String description, String standard_cost,
			String list_price, String reorder_level, String target_level, String quantity_per_unit, String discontinued, String minimum_reorder_quantity,
			String category, Blob attachments) {

		this.id = id;
		this.supplier_ids = supplier_ids;
		this.product_code = product_code;
		this.product_name = product_name;
		this.description = description;
		this.standard_cost = standard_cost;
		this.list_price = list_price;
		this.reorder_level = reorder_level;
		this.target_level = target_level;
		this.quantity_per_unit = quantity_per_unit;
		this.discontinued = discontinued;
		this.minimum_reorder_quantity = minimum_reorder_quantity;
		this.category = category;
		this.attachments = attachments;
		
	}


	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getSupplier_ids() {
		return supplier_ids;
	}

	public void setSupplier_ids(String supplier_ids) {
		this.supplier_ids = supplier_ids;
	}

	public String getProduct_code() {
		return product_code;
	}

	public void setProduct_code(String product_code) {
		this.product_code = product_code;
	}

	public String getProduct_name() {
		return product_name;
	}

	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getStandard_cost() {
		return standard_cost;
	}

	public void setStandard_cost(String standard_cost) {
		this.standard_cost = standard_cost;
	}

	public String getList_price() {
		return list_price;
	}

	public void setList_price(String list_price) {
		this.list_price = list_price;
	}

	public String getReorder_level() {
		return reorder_level;
	}

	public void setReorder_level(String reorder_level) {
		this.reorder_level = reorder_level;
	}

	public String getTarget_level() {
		return target_level;
	}

	public void setTarget_level(String target_level) {
		this.target_level = target_level;
	}

	public String getQuantity_per_unit() {
		return quantity_per_unit;
	}

	public void setQuantity_per_unit(String quantity_per_unit) {
		this.quantity_per_unit = quantity_per_unit;
	}

	public String getDiscontinued() {
		return discontinued;
	}

	public void setDiscontinued(String discontinued) {
		this.discontinued = discontinued;
	}

	public String getMinimum_reorder_quantity() {
		return minimum_reorder_quantity;
	}

	public void setMinimum_reorder_quantity(String minimum_reorder_quantity) {
		this.minimum_reorder_quantity = minimum_reorder_quantity;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public Blob getAttachments() {
		return attachments;
	}

	public void setAttachments(Blob attachments) {
		this.attachments = attachments;
	}

	@Override
	public String toString() {
		return "Products [id=" + id + ", supplier_ids=" + supplier_ids + ", product_code=" + product_code
				+ ", product_name=" + product_name + ", description=" + description + ", standard_cost=" + standard_cost
				+ ", list_price=" + list_price + ", reorder_level=" + reorder_level + ", target_level=" + target_level
				+ ", quantity_per_unit=" + quantity_per_unit + ", discontinued=" + discontinued
				+ ", minimum_reorder_quantity=" + minimum_reorder_quantity + ", category=" + category + ", attachments="
				+ attachments + "]";
	}

	
}